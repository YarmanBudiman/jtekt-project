MVC Adalah 
Model
View 
Controller


--> Data = Model 
--> Tampilan = View
--> Proses = Controller


Kenapa harus MVC
1. Organisasi dan Struktur Kode
2. Pemisahan logic dan Tampilan
3. Perawatan Kode
4. Implementasi Konsep OOP
5. Digunakan dibanyak Web Application Framework

PHP --> CodeIgniter, Laravel, Yii
Java --> Spring MVC
Python --> Django
Ruby --> Ruby on rails
Javascript --> AngularJS


Target dari pembelajaran MVC ini adalah 
1. Pembuatan web menjadi lebih rapih

