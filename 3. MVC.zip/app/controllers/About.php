<?php

class About{

    public function index($nama ='Yarman' ,$pekerjaan ='Staff')
    {
       $this->view('about/index')
    }

    public function page()
    {
        $this->view('about/page')
    }
    
}