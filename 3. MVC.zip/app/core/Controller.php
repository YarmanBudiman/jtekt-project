<?php

class Controller{
    public function __construct()
    {
        echo "<br>";
        echo "Ok controller";
    }
}